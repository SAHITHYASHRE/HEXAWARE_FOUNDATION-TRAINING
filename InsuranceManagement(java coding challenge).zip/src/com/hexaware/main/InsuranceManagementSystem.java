package com.hexaware.main;

import java.sql.Connection;

import java.util.List;
import java.util.Scanner;
import com.hexaware.util.DbConnUtil;
import com.hexaware.dao.IPolicyService;
import com.hexaware.dao.PolicyServiceImpl;
import com.hexaware.model.Policy;
import com.hexaware.exception.PolicyNotFoundException;


public class InsuranceManagementSystem {
	
	 public static void main(String[] args) {
		 
//		 Connection conn = DbConnUtil.getConnection("db.properties");
//	        if (conn != null) {
//	            System.out.println("Database connected successfully!");
//	        } else {
//	            System.out.println("Failed to connect to database.");
//	        }
//	        
//		  Connection conn = DbConnUtil.getConnection("db.properties");
//	        if (conn == null) {
//	            System.out.println("Database connection failed. Exiting...");
//	            return;
//	        }
	        
	        Scanner scanner = new Scanner(System.in);
	        IPolicyService policyService = new PolicyServiceImpl();

	        while (true) {
	            System.out.println("\n===== Insurance Policy Management =====");
	            System.out.println("1. Create Policy");
	            System.out.println("2. View Policy by ID");
	            System.out.println("3. View All Policies");
	            System.out.println("4. Update Policy");
	            System.out.println("5. Delete Policy");
	            System.out.println("6. Exit");
	            System.out.print("Enter your choice: ");
	            
	            int choice = scanner.nextInt();
	            scanner.nextLine(); 
	            
	            try {
	                switch (choice) {
	                    case 1:
	                        System.out.print("Enter Policy Name: ");
	                        String name = scanner.nextLine();
	                        System.out.print("Enter Policy Type: ");
	                        String type = scanner.nextLine();
	                        System.out.print("Enter Premium Amount: ");
	                        double premium = scanner.nextDouble();
	                        System.out.print("Enter Coverage Amount: ");
	                        double coverage = scanner.nextDouble();

	                        Policy newPolicy = new Policy(name, type, premium, coverage);
	                        boolean created = policyService.createPolicy(newPolicy);
	                        System.out.println(created ? "Policy created successfully!" : "Policy creation failed.");
	                        break;

	                    case 2:
	                        System.out.print("Enter Policy ID: ");
	                        int id = scanner.nextInt();
	                        Policy policy = policyService.getPolicy(id);
	                        System.out.println(policy);
	                        break;

	                    case 3:
	                        List<Policy> policies = policyService.getAllPolicies();
	                        if (policies.isEmpty()) {
	                            System.out.println("No policies found.");
	                        } else {
	                            for (Policy p : policies) {
	                                System.out.println(p);
	                            }
	                        }
	                        break;

	                    case 4:
	                        System.out.print("Enter Policy ID to Update: ");
	                        int updateId = scanner.nextInt();
	                        scanner.nextLine(); // consume newline
	                        System.out.print("Enter New Policy Name: ");
	                        String newName = scanner.nextLine();
	                        System.out.print("Enter New Policy Type: ");
	                        String newType = scanner.nextLine();
	                        System.out.print("Enter New Premium Amount: ");
	                        double newPremium = scanner.nextDouble();
	                        System.out.print("Enter New Coverage Amount: ");
	                        double newCoverage = scanner.nextDouble();

	                        Policy updatedPolicy = new Policy(updateId, newName, newType, newPremium, newCoverage);
	                        boolean updated = policyService.updatePolicy(updatedPolicy);
	                        System.out.println(updated ? "Policy updated successfully!" : "Policy update failed.");
	                        break;

	                    case 5:
	                        System.out.print("Enter Policy ID to Delete: ");
	                        int deleteId = scanner.nextInt();
	                        boolean deleted = policyService.deletePolicy(deleteId);
	                        System.out.println(deleted ? "Policy deleted successfully!" : "Policy deletion failed.");
	                        break;

	                    case 6:
	                        System.out.println("Exiting... Goodbye!");
	                        scanner.close();
	                        System.exit(0);

	                    default:
	                        System.out.println("Invalid choice. Please try again.");
	                }
	            } catch (PolicyNotFoundException e) {
	                System.out.println("Error: " + e.getMessage());
	            } catch (Exception e) {
	                System.out.println("Unexpected error: " + e.getMessage());
	            }
	        }
	       
	    }

}
