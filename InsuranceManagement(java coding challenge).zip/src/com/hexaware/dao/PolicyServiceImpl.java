package com.hexaware.dao;

import java.util.List;

import com.hexaware.model.Policy;

import java.sql.*;
import java.util.ArrayList;

import com.hexaware.util.DbConnUtil;
import com.hexaware.exception.PolicyNotFoundException;

public class PolicyServiceImpl implements IPolicyService {
	
	 private static final String DB_PROPERTIES_FILE = "db.properties";

	@Override
	public boolean createPolicy(Policy policy) {
		// TODO Auto-generated method stub
		  String query = "INSERT INTO Policy (policyName, policyType, premiumAmount, coverageAmount) VALUES (?, ?, ?, ?)";
	        try (Connection conn = DbConnUtil.getConnection(DB_PROPERTIES_FILE);
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setString(1, policy.getPolicyName());
	            pstmt.setString(2, policy.getPolicyType());
	            pstmt.setDouble(3, policy.getPremiumAmount());
	            pstmt.setDouble(4, policy.getCoverageAmount());

	            int rows = pstmt.executeUpdate();
	            return rows > 0;

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	        
	}

	@Override
	public Policy getPolicy(int policyId) throws PolicyNotFoundException {
		// TODO Auto-generated method stub
		 String query = "SELECT * FROM Policy WHERE policyId = ?";
	        try (Connection conn = DbConnUtil.getConnection(DB_PROPERTIES_FILE);
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setInt(1, policyId);
	            ResultSet rs = pstmt.executeQuery();

	            if (rs.next()) {
	                return new Policy(
	                        rs.getInt("policyId"),
	                        rs.getString("policyName"),
	                        rs.getString("policyType"),
	                        rs.getDouble("premiumAmount"),
	                        rs.getDouble("coverageAmount")
	                );
	            } else {
	                throw new PolicyNotFoundException("Policy ID " + policyId + " not found.");
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		return null;
	}

	@Override
	public List<Policy> getAllPolicies() {
		// TODO Auto-generated method stub
		List<Policy> policies = new ArrayList<>();
        String query = "SELECT * FROM Policy";
        try (Connection conn = DbConnUtil.getConnection(DB_PROPERTIES_FILE);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Policy policy = new Policy(
                        rs.getInt("policyId"),
                        rs.getString("policyName"),
                        rs.getString("policyType"),
                        rs.getDouble("premiumAmount"),
                        rs.getDouble("coverageAmount")
                );
                policies.add(policy);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policies;
		
	}

	@Override
	public boolean updatePolicy(Policy policy) {
		// TODO Auto-generated method stub
		 String query = "UPDATE Policy SET policyName=?, policyType=?, premiumAmount=?, coverageAmount=? WHERE policyId=?";
	        try (Connection conn = DbConnUtil.getConnection(DB_PROPERTIES_FILE);
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setString(1, policy.getPolicyName());
	            pstmt.setString(2, policy.getPolicyType());
	            pstmt.setDouble(3, policy.getPremiumAmount());
	            pstmt.setDouble(4, policy.getCoverageAmount());
	            pstmt.setInt(5, policy.getPolicyId());

	            int rows = pstmt.executeUpdate();
	            return rows > 0;

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		return false;
	}

	@Override
	public boolean deletePolicy(int policyId) {
		// TODO Auto-generated method stub
	      String query = "DELETE FROM Policy WHERE policyId=?";
	        try (Connection conn = DbConnUtil.getConnection(DB_PROPERTIES_FILE);
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setInt(1, policyId);
	            int rows = pstmt.executeUpdate();
	            return rows > 0;

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		return false;
	}

}
