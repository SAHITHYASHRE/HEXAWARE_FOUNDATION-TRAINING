package com.hexaware.util;

import java.sql.Connection;

public class DbConnection {
	
	 private static Connection connection;

	    public static Connection getConnection() {
	        if (connection == null) {
	            connection = DbConnUtil.getConnection("db.properties");
	        }
	        return connection;
	    }

}

//Connection conn = DBConnection.getConnection(); ex usage in dao