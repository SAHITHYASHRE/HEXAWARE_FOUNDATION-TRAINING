package com.hexaware.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class DbPropertyUtil {
	
//	  public static String getConnectionString(String propertyFileName) {
//	        return PropertyUtil.getPropertyString(propertyFileName);
//	    }
	
	public static Properties getProperties(String fileName) {
        Properties props = new Properties();

        try (InputStream input = DbPropertyUtil.class.getClassLoader().getResourceAsStream(fileName)) {
            if (input == null) {
                System.out.println("Sorry, unable to find " + fileName);
                return null;
            }
            props.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return props;
    }
//
//	public static String getConnectionString(String propertyFileName) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	

	public static String getConnectionString(String propertyFileName) {
		// TODO Auto-generated method stub
		return null;
	}

}
	


