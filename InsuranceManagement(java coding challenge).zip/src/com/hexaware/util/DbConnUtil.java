package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnUtil {
	

	public static Connection getConnection(String propertyFileName) {
        String connStr = DbPropertyUtil.getConnectionString(propertyFileName);
        try {
            return DriverManager.getConnection(connStr);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
