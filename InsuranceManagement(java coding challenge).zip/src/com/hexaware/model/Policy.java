package com.hexaware.model;

public class Policy {
	
	 	private int policyId;
	 	private String policyName;
	    private String policyType;
	    private double premiumAmount;
	    
	    public int getPolicyId() {
			return policyId;
		}
		public void setPolicyId(int policyId) {
			this.policyId = policyId;
		}
		public String getPolicyName() {
			return policyName;
		}
		public void setPolicyName(String policyName) {
			this.policyName = policyName;
		}
		public String getPolicyType() {
			return policyType;
		}
		public void setPolicyType(String policyType) {
			this.policyType = policyType;
		}
		public double getPremiumAmount() {
			return premiumAmount;
		}
		public void setPremiumAmount(double premiumAmount) {
			this.premiumAmount = premiumAmount;
		}
		public Policy() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Policy(int policyId, String policyName, String policyType, double premiumAmount) {
			super();
			this.policyId = policyId;
			this.policyName = policyName;
			this.policyType = policyType;
			this.premiumAmount = premiumAmount;
		}
		public Policy(int int1, String string, String string2, double double1, double double2) {
			// TODO Auto-generated constructor stub
		}
		public Policy(String name, String type, double premium, double coverage) {
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "Policy [policyId=" + policyId + ", policyName=" + policyName + ", policyType=" + policyType
					+ ", premiumAmount=" + premiumAmount + "]";
		}
		public double getCoverageAmount() {
			// TODO Auto-generated method stub
			return 0;
		}
		

}
